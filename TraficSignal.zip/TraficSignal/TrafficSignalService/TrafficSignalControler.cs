﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Barclays.TrafficSignalService
{
    public class TrafficSignalControler
    {
        private TrafficTracker trafficTracker;
        public TrafficSignalControler()
        {
            trafficTracker = new TrafficTracker();
        }

        /// <summary>
        /// It keep track the cars count in each side
        /// </summary>
        /// <param name="roadSide">Its an enumerator to pass the road side SouthBound/NorthBound/WestBound/EastBound</param>
        /// <param name="CarCount">Number of cars reached or leave from the signal. If 1 car reaches pass 1. If 1 car leaves pass -1. Pass 0 to get a current car count in the given road side</param>
        /// <returns>Return back the current car count for the given road side</returns>
        public int TrackCar(RoadSide roadSide, int CarCount)
        {
            switch (roadSide)
            {
                case RoadSide.SouthBound:
                    {
                        trafficTracker.SouthBoundCarsCount += CarCount;
                        return trafficTracker.SouthBoundCarsCount;
                    }
                case RoadSide.NorthBound:
                    {
                        trafficTracker.NorthBoundCarsCount += CarCount;
                        return trafficTracker.NorthBoundCarsCount;
                    }
                case RoadSide.WestBound:
                    {
                        trafficTracker.WestBoundCarsCount += CarCount;
                        return trafficTracker.WestBoundCarsCount;
                    }
                case RoadSide.EastBound:
                    {
                        trafficTracker.EastBoundCarsCount += CarCount;
                        return trafficTracker.EastBoundCarsCount;
                    }
            }
            return -1;
        }

        /// <summary>
        /// Keep track the signal
        /// </summary>
        /// <param name="roadSide">Its an enumerator to pass the road side SouthBound/NorthBound/WestBound/EastBound</param>
        /// <param name="IsGreen">Pass true if green. Pass false if red</param>
        /// <returns>Return true if valid else this will return false</returns>
        public bool TrackSignal(RoadSide roadSide, bool IsGreen)
        {
            switch (roadSide)
            {
                case RoadSide.SouthBound:
                    {
                        if (IsGreen && (trafficTracker.IsWestBoundGreen || trafficTracker.IsEastBoundGreen))
                            return false;
                        trafficTracker.IsSouthBoundGreen = IsGreen;
                        return true;
                    }
                case RoadSide.NorthBound:
                    {
                        if (IsGreen && (trafficTracker.IsWestBoundGreen || trafficTracker.IsEastBoundGreen))
                            return false;
                        trafficTracker.IsNorthBoundGreen = IsGreen;
                        return true;
                    }
                case RoadSide.WestBound:
                    {
                        if (IsGreen && (trafficTracker.IsSouthBoundGreen || trafficTracker.IsNorthBoundGreen))
                            return false;
                        trafficTracker.IsWestBoundGreen = IsGreen;
                        return true;
                    }
                case RoadSide.EastBound:
                    {
                        if (IsGreen && (trafficTracker.IsSouthBoundGreen || trafficTracker.IsNorthBoundGreen))
                            return false;
                        trafficTracker.IsEastBoundGreen = IsGreen;
                        return true;
                    }
            }
            return false;
        }

        /// <summary>
        /// Get current signal for the given road side
        /// </summary>
        /// <param name="roadSide">Its an enumerator to pass the road side SouthBound/NorthBound/WestBound/EastBound</param>
        /// <returns>Return true if given road side signal is green. Else it will return false</returns>
        public bool GetSignal(RoadSide roadSide)
        {
            switch (roadSide)
            {
                case RoadSide.SouthBound:return trafficTracker.IsSouthBoundGreen;
                case RoadSide.NorthBound: return trafficTracker.IsNorthBoundGreen;
                case RoadSide.WestBound: return trafficTracker.IsWestBoundGreen;
                case RoadSide.EastBound: return trafficTracker.IsEastBoundGreen;
            }
            return false;
        }

        /// <summary>
        /// Get the result to print
        /// </summary>
        /// <returns></returns>
        public string GetCarCount()
        {
            return "N = " + trafficTracker.NorthBoundCarsCount + "; S = " + trafficTracker.SouthBoundCarsCount + "; E = " + trafficTracker.EastBoundCarsCount + "; W = " + trafficTracker.WestBoundCarsCount + "";
        }
    }
}
