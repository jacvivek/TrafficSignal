﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Barclays.TrafficSignalService
{
    /// <summary>
    /// Day of week
    /// </summary>
    public enum RoadSide
    {
        SouthBound=1,
        NorthBound=2,
        EastBound=3,
        WestBound = 4
    }
}
