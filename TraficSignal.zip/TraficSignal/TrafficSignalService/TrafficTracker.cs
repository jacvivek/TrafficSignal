﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Barclays.TrafficSignalService
{
    internal class TrafficTracker
    {
        public bool IsSouthBoundGreen { get; set; }
        public bool IsNorthBoundGreen { get; set; }
        public bool IsEastBoundGreen { get; set; }
        public bool IsWestBoundGreen { get; set; }
        public int SouthBoundCarsCount { get; set; }
        public int NorthBoundCarsCount { get; set; }
        public int EastBoundCarsCount { get; set; }
        public int WestBoundCarsCount { get; set; }
    }
}
