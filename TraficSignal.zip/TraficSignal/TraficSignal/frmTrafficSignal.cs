﻿using Barclays.TrafficSignalService;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Barclays.TrafficSignal
{
    public partial class frmTrafficSignal : Form
    {
        private TrafficSignalControler trafficSignalControler;
        private int totalTime = 0;
        private int SouthandNorthGreenSignalTime = 3;
        private int EastandWestGreenSignalTime = 3;
        private RoadSide nextSignalSide = RoadSide.EastBound;
        public frmTrafficSignal()
        {
            InitializeComponent(); 
        }

        /// <summary>
        /// To start and stop the signal
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnStartOrStop_Click(object sender, EventArgs e)
        {
            if (btnStartOrStop.Text == "Start")
            {
                trafficSignalControler = new TrafficSignalControler();
                trafficSignalControler.TrackSignal(RoadSide.SouthBound, true);
                trafficSignalControler.TrackSignal(RoadSide.NorthBound, true);
                setSignal();
                txtResult.Text = totalTime + ": " + trafficSignalControler.GetCarCount();
                btnStartOrStop.Text = "Stop";
                timer1.Start();
            }
            else if (btnStartOrStop.Text == "Stop")
            {
                btnStartOrStop.Text = "Start";
                totalTime = 0;
                timer1.Stop();
            }
            
        }

        /// <summary>
        /// Timer event to execute the traffic signal
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timer1_Tick(object sender, EventArgs e)
        {
            totalTime += 1;
            setCarArrival(1);

            //To change the signal
            if (!trafficSignalControler.GetSignal(RoadSide.SouthBound) && !trafficSignalControler.GetSignal(RoadSide.NorthBound) &&
                !trafficSignalControler.GetSignal(RoadSide.EastBound) && !trafficSignalControler.GetSignal(RoadSide.WestBound))
            {
                if (nextSignalSide == RoadSide.EastBound)
                {
                    trafficSignalControler.TrackSignal(RoadSide.EastBound, true);
                    trafficSignalControler.TrackSignal(RoadSide.WestBound, true);
                }
                else
                {
                    trafficSignalControler.TrackSignal(RoadSide.SouthBound, true);
                    trafficSignalControler.TrackSignal(RoadSide.NorthBound, true);
                }

            }
            
            //code for South and North bound road signal
            if (trafficSignalControler.GetSignal(RoadSide.SouthBound) && trafficSignalControler.GetSignal(RoadSide.NorthBound))
            {
                if (totalTime == 1 || totalTime % (SouthandNorthGreenSignalTime + 1) > 1)
                {
                    trafficSignalControler.TrackCar(RoadSide.SouthBound, -1);
                    trafficSignalControler.TrackCar(RoadSide.NorthBound, -1);
                }
                if (totalTime % (SouthandNorthGreenSignalTime + 1) > SouthandNorthGreenSignalTime - 1)
                {
                    trafficSignalControler.TrackSignal(RoadSide.SouthBound, false);
                    trafficSignalControler.TrackSignal(RoadSide.NorthBound, false);
                    nextSignalSide = RoadSide.EastBound;
                }
            }

            //code for East and West bound road signal
            if (trafficSignalControler.GetSignal(RoadSide.EastBound) && trafficSignalControler.GetSignal(RoadSide.WestBound))
            {
                if (totalTime == 1 || totalTime % (SouthandNorthGreenSignalTime + 1) > 1)
                {
                    trafficSignalControler.TrackCar(RoadSide.EastBound, -1);
                    trafficSignalControler.TrackCar(RoadSide.WestBound, -1);
                }
                if (totalTime % (SouthandNorthGreenSignalTime + 1) > SouthandNorthGreenSignalTime - 1)
                {
                    trafficSignalControler.TrackSignal(RoadSide.EastBound, false);
                    trafficSignalControler.TrackSignal(RoadSide.WestBound, false);
                    nextSignalSide = RoadSide.SouthBound;
                }
            }
            setSignal();
            txtResult.Text += Environment.NewLine + totalTime + ": " + trafficSignalControler.GetCarCount();
        }

        /// <summary>
        /// Set car arrival
        /// </summary>
        /// <param name="noOfCarsPerSecond">Number Of Cars Per Second</param>
        private void setCarArrival(int noOfCarsPerSecond)
        {
            trafficSignalControler.TrackCar(RoadSide.SouthBound, noOfCarsPerSecond);
            trafficSignalControler.TrackCar(RoadSide.NorthBound, noOfCarsPerSecond);
            trafficSignalControler.TrackCar(RoadSide.EastBound, noOfCarsPerSecond);
            trafficSignalControler.TrackCar(RoadSide.WestBound, noOfCarsPerSecond);
        }

        /// <summary>
        /// Set signal color on signal
        /// </summary>
        private void setSignal()
        {
            txtSouthBound.BackColor = getSignalColor(trafficSignalControler.GetSignal(RoadSide.SouthBound));
            txtNorthBound.BackColor = getSignalColor(trafficSignalControler.GetSignal(RoadSide.NorthBound));
            txtEastBound.BackColor = getSignalColor(trafficSignalControler.GetSignal(RoadSide.EastBound));
            txtWestBound.BackColor = getSignalColor(trafficSignalControler.GetSignal(RoadSide.WestBound));
        }

        /// <summary>
        /// Get color to show in the signal
        /// </summary>
        /// <param name="isGreen"></param>
        /// <returns></returns>
        private Color getSignalColor(bool isGreen)
        {
            return isGreen ? Color.Green : Color.Red;
        }
    }
}
