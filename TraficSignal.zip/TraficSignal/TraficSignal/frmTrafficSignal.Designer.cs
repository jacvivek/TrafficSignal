﻿namespace Barclays.TrafficSignal
{
    partial class frmTrafficSignal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.txtResult = new System.Windows.Forms.RichTextBox();
            this.btnStartOrStop = new System.Windows.Forms.Button();
            this.txtWestBound = new System.Windows.Forms.TextBox();
            this.txtEastBound = new System.Windows.Forms.TextBox();
            this.txtNorthBound = new System.Windows.Forms.TextBox();
            this.txtSouthBound = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // txtResult
            // 
            this.txtResult.Location = new System.Drawing.Point(12, 281);
            this.txtResult.Name = "txtResult";
            this.txtResult.Size = new System.Drawing.Size(457, 285);
            this.txtResult.TabIndex = 0;
            this.txtResult.Text = "";
            // 
            // btnStartOrStop
            // 
            this.btnStartOrStop.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.btnStartOrStop.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStartOrStop.Location = new System.Drawing.Point(205, 2);
            this.btnStartOrStop.Name = "btnStartOrStop";
            this.btnStartOrStop.Size = new System.Drawing.Size(80, 31);
            this.btnStartOrStop.TabIndex = 1;
            this.btnStartOrStop.Text = "Start";
            this.btnStartOrStop.UseVisualStyleBackColor = true;
            this.btnStartOrStop.Click += new System.EventHandler(this.btnStartOrStop_Click);
            // 
            // txtWestBound
            // 
            this.txtWestBound.BackColor = System.Drawing.Color.Red;
            this.txtWestBound.Location = new System.Drawing.Point(118, 164);
            this.txtWestBound.Name = "txtWestBound";
            this.txtWestBound.Size = new System.Drawing.Size(100, 20);
            this.txtWestBound.TabIndex = 2;
            this.txtWestBound.Text = "W";
            this.txtWestBound.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtEastBound
            // 
            this.txtEastBound.BackColor = System.Drawing.Color.Red;
            this.txtEastBound.Location = new System.Drawing.Point(264, 142);
            this.txtEastBound.Name = "txtEastBound";
            this.txtEastBound.Size = new System.Drawing.Size(100, 20);
            this.txtEastBound.TabIndex = 3;
            this.txtEastBound.Text = "E";
            // 
            // txtNorthBound
            // 
            this.txtNorthBound.BackColor = System.Drawing.Color.Red;
            this.txtNorthBound.Location = new System.Drawing.Point(219, 57);
            this.txtNorthBound.Multiline = true;
            this.txtNorthBound.Name = "txtNorthBound";
            this.txtNorthBound.Size = new System.Drawing.Size(24, 82);
            this.txtNorthBound.TabIndex = 4;
            this.txtNorthBound.Text = "\r\n\r\n\r\n\r\nN";
            this.txtNorthBound.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtSouthBound
            // 
            this.txtSouthBound.BackColor = System.Drawing.Color.Red;
            this.txtSouthBound.Location = new System.Drawing.Point(242, 188);
            this.txtSouthBound.Multiline = true;
            this.txtSouthBound.Name = "txtSouthBound";
            this.txtSouthBound.Size = new System.Drawing.Size(24, 87);
            this.txtSouthBound.TabIndex = 5;
            this.txtSouthBound.Text = "S";
            // 
            // frmTrafficSignal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(505, 567);
            this.Controls.Add(this.txtSouthBound);
            this.Controls.Add(this.txtNorthBound);
            this.Controls.Add(this.txtEastBound);
            this.Controls.Add(this.txtWestBound);
            this.Controls.Add(this.btnStartOrStop);
            this.Controls.Add(this.txtResult);
            this.Name = "frmTrafficSignal";
            this.Text = "Traffic Signal";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.RichTextBox txtResult;
        private System.Windows.Forms.Button btnStartOrStop;
        private System.Windows.Forms.TextBox txtWestBound;
        private System.Windows.Forms.TextBox txtEastBound;
        private System.Windows.Forms.TextBox txtNorthBound;
        private System.Windows.Forms.TextBox txtSouthBound;
    }
}

